import{h as Rr,g as Fr,j as ze}from"./aria2-extension.js";var Pr={};/*! *****************************************************************************
Copyright (C) Microsoft. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */var Nr;function Pt(){if(Nr)return Pr;Nr=1;var u;return function(n){(function(i){var a=typeof globalThis=="object"?globalThis:typeof Rr=="object"?Rr:typeof self=="object"?self:typeof this=="object"?this:w(),p=h(n);typeof a.Reflect<"u"&&(p=h(a.Reflect,p)),i(p,a),typeof a.Reflect>"u"&&(a.Reflect=n);function h(M,c){return function(_,x){Object.defineProperty(M,_,{configurable:!0,writable:!0,value:x}),c&&c(_,x)}}function l(){try{return Function("return this;")()}catch{}}function y(){try{return(0,eval)("(function() { return this; })()")}catch{}}function w(){return l()||y()}})(function(i,a){var p=Object.prototype.hasOwnProperty,h=typeof Symbol=="function",l=h&&typeof Symbol.toPrimitive<"u"?Symbol.toPrimitive:"@@toPrimitive",y=h&&typeof Symbol.iterator<"u"?Symbol.iterator:"@@iterator",w=typeof Object.create=="function",M={__proto__:[]}instanceof Array,c=!w&&!M,_={create:w?function(){return r(Object.create(null))}:M?function(){return r({__proto__:null})}:function(){return r({})},has:c?function(e,t){return p.call(e,t)}:function(e,t){return t in e},get:c?function(e,t){return p.call(e,t)?e[t]:void 0}:function(e,t){return e[t]}},x=Object.getPrototypeOf(Function),m=typeof Map=="function"&&typeof Map.prototype.entries=="function"?Map:ne(),$=typeof Set=="function"&&typeof Set.prototype.entries=="function"?Set:Je(),L=typeof WeakMap=="function"?WeakMap:o(),A=h?Symbol.for("@reflect-metadata:registry"):void 0,R=ge(),k=V(R);function D(e,t,s,f){if(B(s)){if(!we(e))throw new TypeError;if(!ke(t))throw new TypeError;return ye(e,t)}else{if(!we(e))throw new TypeError;if(!G(t))throw new TypeError;if(!G(f)&&!B(f)&&!q(f))throw new TypeError;return q(f)&&(f=void 0),s=z(s),me(e,t,s,f)}}i("decorate",D);function Z(e,t){function s(f,d){if(!G(f))throw new TypeError;if(!B(d)&&!Ue(d))throw new TypeError;Ce(e,t,f,d)}return s}i("metadata",Z);function F(e,t,s,f){if(!G(s))throw new TypeError;return B(f)||(f=z(f)),Ce(e,t,s,f)}i("defineMetadata",F);function W(e,t,s){if(!G(t))throw new TypeError;return B(s)||(s=z(s)),oe(e,t,s)}i("hasMetadata",W);function K(e,t,s){if(!G(t))throw new TypeError;return B(s)||(s=z(s)),U(e,t,s)}i("hasOwnMetadata",K);function P(e,t,s){if(!G(t))throw new TypeError;return B(s)||(s=z(s)),Y(e,t,s)}i("getMetadata",P);function he(e,t,s){if(!G(t))throw new TypeError;return B(s)||(s=z(s)),Me(e,t,s)}i("getOwnMetadata",he);function ue(e,t){if(!G(e))throw new TypeError;return B(t)||(t=z(t)),Te(e,t)}i("getMetadataKeys",ue);function le(e,t){if(!G(e))throw new TypeError;return B(t)||(t=z(t)),Re(e,t)}i("getOwnMetadataKeys",le);function de(e,t,s){if(!G(t))throw new TypeError;if(B(s)||(s=z(s)),!G(t))throw new TypeError;B(s)||(s=z(s));var f=ce(t,s,!1);return B(f)?!1:f.OrdinaryDeleteMetadata(e,t,s)}i("deleteMetadata",de);function ye(e,t){for(var s=e.length-1;s>=0;--s){var f=e[s],d=f(t);if(!B(d)&&!q(d)){if(!ke(d))throw new TypeError;t=d}}return t}function me(e,t,s,f){for(var d=e.length-1;d>=0;--d){var I=e[d],O=I(t,s,f);if(!B(O)&&!q(O)){if(!G(O))throw new TypeError;f=O}}return f}function oe(e,t,s){var f=U(e,t,s);if(f)return!0;var d=Be(t);return q(d)?!1:oe(e,d,s)}function U(e,t,s){var f=ce(t,s,!1);return B(f)?!1:Ae(f.OrdinaryHasOwnMetadata(e,t,s))}function Y(e,t,s){var f=U(e,t,s);if(f)return Me(e,t,s);var d=Be(t);if(!q(d))return Y(e,d,s)}function Me(e,t,s){var f=ce(t,s,!1);if(!B(f))return f.OrdinaryGetOwnMetadata(e,t,s)}function Ce(e,t,s,f){var d=ce(s,f,!0);d.OrdinaryDefineOwnMetadata(e,t,s,f)}function Te(e,t){var s=Re(e,t),f=Be(e);if(f===null)return s;var d=Te(f,t);if(d.length<=0)return s;if(s.length<=0)return d;for(var I=new $,O=[],S=0,v=s;S<v.length;S++){var g=v[S],E=I.has(g);E||(I.add(g),O.push(g))}for(var b=0,T=d;b<T.length;b++){var g=T[b],E=I.has(g);E||(I.add(g),O.push(g))}return O}function Re(e,t){var s=ce(e,t,!1);return s?s.OrdinaryOwnMetadataKeys(e,t):[]}function Fe(e){if(e===null)return 1;switch(typeof e){case"undefined":return 0;case"boolean":return 2;case"string":return 3;case"symbol":return 4;case"number":return 5;case"object":return e===null?1:6;default:return 6}}function B(e){return e===void 0}function q(e){return e===null}function H(e){return typeof e=="symbol"}function G(e){return typeof e=="object"?e!==null:typeof e=="function"}function Pe(e,t){switch(Fe(e)){case 0:return e;case 1:return e;case 2:return e;case 3:return e;case 4:return e;case 5:return e}var s="string",f=ae(e,l);if(f!==void 0){var d=f.call(e,s);if(G(d))throw new TypeError;return d}return Ne(e)}function Ne(e,t){var s,f,d;{var I=e.toString;if(fe(I)){var f=I.call(e);if(!G(f))return f}var s=e.valueOf;if(fe(s)){var f=s.call(e);if(!G(f))return f}}throw new TypeError}function Ae(e){return!!e}function $e(e){return""+e}function z(e){var t=Pe(e);return H(t)?t:$e(t)}function we(e){return Array.isArray?Array.isArray(e):e instanceof Object?e instanceof Array:Object.prototype.toString.call(e)==="[object Array]"}function fe(e){return typeof e=="function"}function ke(e){return typeof e=="function"}function Ue(e){switch(Fe(e)){case 3:return!0;case 4:return!0;default:return!1}}function te(e,t){return e===t||e!==e&&t!==t}function ae(e,t){var s=e[t];if(s!=null){if(!fe(s))throw new TypeError;return s}}function De(e){var t=ae(e,y);if(!fe(t))throw new TypeError;var s=t.call(e);if(!G(s))throw new TypeError;return s}function qe(e){return e.value}function ve(e){var t=e.next();return t.done?!1:t}function je(e){var t=e.return;t&&t.call(e)}function Be(e){var t=Object.getPrototypeOf(e);if(typeof e!="function"||e===x||t!==x)return t;var s=e.prototype,f=s&&Object.getPrototypeOf(s);if(f==null||f===Object.prototype)return t;var d=f.constructor;return typeof d!="function"||d===e?t:d}function Ge(){var e;!B(A)&&typeof a.Reflect<"u"&&!(A in a.Reflect)&&typeof a.Reflect.defineMetadata=="function"&&(e=Oe(a.Reflect));var t,s,f,d=new L,I={registerProvider:O,getProvider:v,setProvider:E};return I;function O(b){if(!Object.isExtensible(I))throw new Error("Cannot add provider to a frozen registry.");switch(!0){case e===b:break;case B(t):t=b;break;case t===b:break;case B(s):s=b;break;case s===b:break;default:f===void 0&&(f=new $),f.add(b);break}}function S(b,T){if(!B(t)){if(t.isProviderFor(b,T))return t;if(!B(s)){if(s.isProviderFor(b,T))return t;if(!B(f))for(var j=De(f);;){var X=ve(j);if(!X)return;var re=qe(X);if(re.isProviderFor(b,T))return je(j),re}}}if(!B(e)&&e.isProviderFor(b,T))return e}function v(b,T){var j=d.get(b),X;return B(j)||(X=j.get(T)),B(X)&&(X=S(b,T),B(X)||(B(j)&&(j=new m,d.set(b,j)),j.set(T,X))),X}function g(b){if(B(b))throw new TypeError;return t===b||s===b||!B(f)&&f.has(b)}function E(b,T,j){if(!g(j))throw new Error("Metadata provider not registered.");var X=v(b,T);if(X!==j){if(!B(X))return!1;var re=d.get(b);B(re)&&(re=new m,d.set(b,re)),re.set(T,j)}return!0}}function ge(){var e;return!B(A)&&G(a.Reflect)&&Object.isExtensible(a.Reflect)&&(e=a.Reflect[A]),B(e)&&(e=Ge()),!B(A)&&G(a.Reflect)&&Object.isExtensible(a.Reflect)&&Object.defineProperty(a.Reflect,A,{enumerable:!1,configurable:!1,writable:!1,value:e}),e}function V(e){var t=new L,s={isProviderFor:function(g,E){var b=t.get(g);return B(b)?!1:b.has(E)},OrdinaryDefineOwnMetadata:O,OrdinaryHasOwnMetadata:d,OrdinaryGetOwnMetadata:I,OrdinaryOwnMetadataKeys:S,OrdinaryDeleteMetadata:v};return R.registerProvider(s),s;function f(g,E,b){var T=t.get(g),j=!1;if(B(T)){if(!b)return;T=new m,t.set(g,T),j=!0}var X=T.get(E);if(B(X)){if(!b)return;if(X=new m,T.set(E,X),!e.setProvider(g,E,s))throw T.delete(E),j&&t.delete(g),new Error("Wrong provider for target.")}return X}function d(g,E,b){var T=f(E,b,!1);return B(T)?!1:Ae(T.has(g))}function I(g,E,b){var T=f(E,b,!1);if(!B(T))return T.get(g)}function O(g,E,b,T){var j=f(b,T,!0);j.set(g,E)}function S(g,E){var b=[],T=f(g,E,!1);if(B(T))return b;for(var j=T.keys(),X=De(j),re=0;;){var Tr=ve(X);if(!Tr)return b.length=re,b;var Rt=qe(Tr);try{b[re]=Rt}catch(Ft){try{je(X)}finally{throw Ft}}re++}}function v(g,E,b){var T=f(E,b,!1);if(B(T)||!T.delete(g))return!1;if(T.size===0){var j=t.get(E);B(j)||(j.delete(b),j.size===0&&t.delete(j))}return!0}}function Oe(e){var t=e.defineMetadata,s=e.hasOwnMetadata,f=e.getOwnMetadata,d=e.getOwnMetadataKeys,I=e.deleteMetadata,O=new L,S={isProviderFor:function(v,g){var E=O.get(v);return!B(E)&&E.has(g)?!0:d(v,g).length?(B(E)&&(E=new $,O.set(v,E)),E.add(g),!0):!1},OrdinaryDefineOwnMetadata:t,OrdinaryHasOwnMetadata:s,OrdinaryGetOwnMetadata:f,OrdinaryOwnMetadataKeys:d,OrdinaryDeleteMetadata:I};return S}function ce(e,t,s){var f=R.getProvider(e,t);if(!B(f))return f;if(s){if(R.setProvider(e,t,k))return k;throw new Error("Illegal state.")}}function ne(){var e={},t=[],s=function(){function S(v,g,E){this._index=0,this._keys=v,this._values=g,this._selector=E}return S.prototype["@@iterator"]=function(){return this},S.prototype[y]=function(){return this},S.prototype.next=function(){var v=this._index;if(v>=0&&v<this._keys.length){var g=this._selector(this._keys[v],this._values[v]);return v+1>=this._keys.length?(this._index=-1,this._keys=t,this._values=t):this._index++,{value:g,done:!1}}return{value:void 0,done:!0}},S.prototype.throw=function(v){throw this._index>=0&&(this._index=-1,this._keys=t,this._values=t),v},S.prototype.return=function(v){return this._index>=0&&(this._index=-1,this._keys=t,this._values=t),{value:v,done:!0}},S}(),f=function(){function S(){this._keys=[],this._values=[],this._cacheKey=e,this._cacheIndex=-2}return Object.defineProperty(S.prototype,"size",{get:function(){return this._keys.length},enumerable:!0,configurable:!0}),S.prototype.has=function(v){return this._find(v,!1)>=0},S.prototype.get=function(v){var g=this._find(v,!1);return g>=0?this._values[g]:void 0},S.prototype.set=function(v,g){var E=this._find(v,!0);return this._values[E]=g,this},S.prototype.delete=function(v){var g=this._find(v,!1);if(g>=0){for(var E=this._keys.length,b=g+1;b<E;b++)this._keys[b-1]=this._keys[b],this._values[b-1]=this._values[b];return this._keys.length--,this._values.length--,te(v,this._cacheKey)&&(this._cacheKey=e,this._cacheIndex=-2),!0}return!1},S.prototype.clear=function(){this._keys.length=0,this._values.length=0,this._cacheKey=e,this._cacheIndex=-2},S.prototype.keys=function(){return new s(this._keys,this._values,d)},S.prototype.values=function(){return new s(this._keys,this._values,I)},S.prototype.entries=function(){return new s(this._keys,this._values,O)},S.prototype["@@iterator"]=function(){return this.entries()},S.prototype[y]=function(){return this.entries()},S.prototype._find=function(v,g){if(!te(this._cacheKey,v)){this._cacheIndex=-1;for(var E=0;E<this._keys.length;E++)if(te(this._keys[E],v)){this._cacheIndex=E;break}}return this._cacheIndex<0&&g&&(this._cacheIndex=this._keys.length,this._keys.push(v),this._values.push(void 0)),this._cacheIndex},S}();return f;function d(S,v){return S}function I(S,v){return v}function O(S,v){return[S,v]}}function Je(){var e=function(){function t(){this._map=new m}return Object.defineProperty(t.prototype,"size",{get:function(){return this._map.size},enumerable:!0,configurable:!0}),t.prototype.has=function(s){return this._map.has(s)},t.prototype.add=function(s){return this._map.set(s,s),this},t.prototype.delete=function(s){return this._map.delete(s)},t.prototype.clear=function(){this._map.clear()},t.prototype.keys=function(){return this._map.keys()},t.prototype.values=function(){return this._map.keys()},t.prototype.entries=function(){return this._map.entries()},t.prototype["@@iterator"]=function(){return this.keys()},t.prototype[y]=function(){return this.keys()},t}();return e}function o(){var e=16,t=_.create(),s=f();return function(){function v(){this._key=f()}return v.prototype.has=function(g){var E=d(g,!1);return E!==void 0?_.has(E,this._key):!1},v.prototype.get=function(g){var E=d(g,!1);return E!==void 0?_.get(E,this._key):void 0},v.prototype.set=function(g,E){var b=d(g,!0);return b[this._key]=E,this},v.prototype.delete=function(g){var E=d(g,!1);return E!==void 0?delete E[this._key]:!1},v.prototype.clear=function(){this._key=f()},v}();function f(){var v;do v="@@WeakMap@@"+S();while(_.has(t,v));return t[v]=!0,v}function d(v,g){if(!p.call(v,s)){if(!g)return;Object.defineProperty(v,s,{value:_.create()})}return v[s]}function I(v,g){for(var E=0;E<g;++E)v[E]=Math.random()*255|0;return v}function O(v){if(typeof Uint8Array=="function"){var g=new Uint8Array(v);return typeof crypto<"u"?crypto.getRandomValues(g):typeof msCrypto<"u"?msCrypto.getRandomValues(g):I(g,v),g}return I(new Array(v),v)}function S(){var v=O(e);v[6]=v[6]&79|64,v[8]=v[8]&191|128;for(var g="",E=0;E<e;++E){var b=v[E];(E===4||E===6||E===8)&&(g+="-"),b<16&&(g+="0"),g+=b.toString(16).toLowerCase()}return g}}function r(e){return e.__=void 0,delete e.__,e}})}(u||(u={})),Pr}Pt();var vt={},Ze={};Ze.byteLength=kt;Ze.toByteArray=Dt;Ze.fromByteArray=Gt;var ie=[],ee=[],Nt=typeof Uint8Array<"u"?Uint8Array:Array,Ye="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(var xe=0,$t=Ye.length;xe<$t;++xe)ie[xe]=Ye[xe],ee[Ye.charCodeAt(xe)]=xe;ee[45]=62;ee[95]=63;function gt(u){var n=u.length;if(n%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var i=u.indexOf("=");i===-1&&(i=n);var a=i===n?0:4-i%4;return[i,a]}function kt(u){var n=gt(u),i=n[0],a=n[1];return(i+a)*3/4-a}function Ut(u,n,i){return(n+i)*3/4-i}function Dt(u){var n,i=gt(u),a=i[0],p=i[1],h=new Nt(Ut(u,a,p)),l=0,y=p>0?a-4:a,w;for(w=0;w<y;w+=4)n=ee[u.charCodeAt(w)]<<18|ee[u.charCodeAt(w+1)]<<12|ee[u.charCodeAt(w+2)]<<6|ee[u.charCodeAt(w+3)],h[l++]=n>>16&255,h[l++]=n>>8&255,h[l++]=n&255;return p===2&&(n=ee[u.charCodeAt(w)]<<2|ee[u.charCodeAt(w+1)]>>4,h[l++]=n&255),p===1&&(n=ee[u.charCodeAt(w)]<<10|ee[u.charCodeAt(w+1)]<<4|ee[u.charCodeAt(w+2)]>>2,h[l++]=n>>8&255,h[l++]=n&255),h}function qt(u){return ie[u>>18&63]+ie[u>>12&63]+ie[u>>6&63]+ie[u&63]}function jt(u,n,i){for(var a,p=[],h=n;h<i;h+=3)a=(u[h]<<16&16711680)+(u[h+1]<<8&65280)+(u[h+2]&255),p.push(qt(a));return p.join("")}function Gt(u){for(var n,i=u.length,a=i%3,p=[],h=16383,l=0,y=i-a;l<y;l+=h)p.push(jt(u,l,l+h>y?y:l+h));return a===1?(n=u[i-1],p.push(ie[n>>2]+ie[n<<4&63]+"==")):a===2&&(n=(u[i-2]<<8)+u[i-1],p.push(ie[n>>10]+ie[n>>4&63]+ie[n<<2&63]+"=")),p.join("")}var Lr={};/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */Lr.read=function(u,n,i,a,p){var h,l,y=p*8-a-1,w=(1<<y)-1,M=w>>1,c=-7,_=i?p-1:0,x=i?-1:1,m=u[n+_];for(_+=x,h=m&(1<<-c)-1,m>>=-c,c+=y;c>0;h=h*256+u[n+_],_+=x,c-=8);for(l=h&(1<<-c)-1,h>>=-c,c+=a;c>0;l=l*256+u[n+_],_+=x,c-=8);if(h===0)h=1-M;else{if(h===w)return l?NaN:(m?-1:1)*(1/0);l=l+Math.pow(2,a),h=h-M}return(m?-1:1)*l*Math.pow(2,h-a)};Lr.write=function(u,n,i,a,p,h){var l,y,w,M=h*8-p-1,c=(1<<M)-1,_=c>>1,x=p===23?Math.pow(2,-24)-Math.pow(2,-77):0,m=a?0:h-1,$=a?1:-1,L=n<0||n===0&&1/n<0?1:0;for(n=Math.abs(n),isNaN(n)||n===1/0?(y=isNaN(n)?1:0,l=c):(l=Math.floor(Math.log(n)/Math.LN2),n*(w=Math.pow(2,-l))<1&&(l--,w*=2),l+_>=1?n+=x/w:n+=x*Math.pow(2,1-_),n*w>=2&&(l++,w/=2),l+_>=c?(y=0,l=c):l+_>=1?(y=(n*w-1)*Math.pow(2,p),l=l+_):(y=n*Math.pow(2,_-1)*Math.pow(2,p),l=0));p>=8;u[i+m]=y&255,m+=$,y/=256,p-=8);for(l=l<<p|y,M+=p;M>0;u[i+m]=l&255,m+=$,l/=256,M-=8);u[i+m-$]|=L*128};/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */(function(u){const n=Ze,i=Lr,a=typeof Symbol=="function"&&typeof Symbol.for=="function"?Symbol.for("nodejs.util.inspect.custom"):null;u.Buffer=c,u.SlowBuffer=F,u.INSPECT_MAX_BYTES=50;const p=2147483647;u.kMaxLength=p;const{Uint8Array:h,ArrayBuffer:l,SharedArrayBuffer:y}=globalThis;c.TYPED_ARRAY_SUPPORT=w(),!c.TYPED_ARRAY_SUPPORT&&typeof console<"u"&&typeof console.error=="function"&&console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");function w(){try{const o=new h(1),r={foo:function(){return 42}};return Object.setPrototypeOf(r,h.prototype),Object.setPrototypeOf(o,r),o.foo()===42}catch{return!1}}Object.defineProperty(c.prototype,"parent",{enumerable:!0,get:function(){if(c.isBuffer(this))return this.buffer}}),Object.defineProperty(c.prototype,"offset",{enumerable:!0,get:function(){if(c.isBuffer(this))return this.byteOffset}});function M(o){if(o>p)throw new RangeError('The value "'+o+'" is invalid for option "size"');const r=new h(o);return Object.setPrototypeOf(r,c.prototype),r}function c(o,r,e){if(typeof o=="number"){if(typeof r=="string")throw new TypeError('The "string" argument must be of type string. Received type number');return $(o)}return _(o,r,e)}c.poolSize=8192;function _(o,r,e){if(typeof o=="string")return L(o,r);if(l.isView(o))return R(o);if(o==null)throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type "+typeof o);if(V(o,l)||o&&V(o.buffer,l)||typeof y<"u"&&(V(o,y)||o&&V(o.buffer,y)))return k(o,r,e);if(typeof o=="number")throw new TypeError('The "value" argument must not be of type number. Received type number');const t=o.valueOf&&o.valueOf();if(t!=null&&t!==o)return c.from(t,r,e);const s=D(o);if(s)return s;if(typeof Symbol<"u"&&Symbol.toPrimitive!=null&&typeof o[Symbol.toPrimitive]=="function")return c.from(o[Symbol.toPrimitive]("string"),r,e);throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type "+typeof o)}c.from=function(o,r,e){return _(o,r,e)},Object.setPrototypeOf(c.prototype,h.prototype),Object.setPrototypeOf(c,h);function x(o){if(typeof o!="number")throw new TypeError('"size" argument must be of type number');if(o<0)throw new RangeError('The value "'+o+'" is invalid for option "size"')}function m(o,r,e){return x(o),o<=0?M(o):r!==void 0?typeof e=="string"?M(o).fill(r,e):M(o).fill(r):M(o)}c.alloc=function(o,r,e){return m(o,r,e)};function $(o){return x(o),M(o<0?0:Z(o)|0)}c.allocUnsafe=function(o){return $(o)},c.allocUnsafeSlow=function(o){return $(o)};function L(o,r){if((typeof r!="string"||r==="")&&(r="utf8"),!c.isEncoding(r))throw new TypeError("Unknown encoding: "+r);const e=W(o,r)|0;let t=M(e);const s=t.write(o,r);return s!==e&&(t=t.slice(0,s)),t}function A(o){const r=o.length<0?0:Z(o.length)|0,e=M(r);for(let t=0;t<r;t+=1)e[t]=o[t]&255;return e}function R(o){if(V(o,h)){const r=new h(o);return k(r.buffer,r.byteOffset,r.byteLength)}return A(o)}function k(o,r,e){if(r<0||o.byteLength<r)throw new RangeError('"offset" is outside of buffer bounds');if(o.byteLength<r+(e||0))throw new RangeError('"length" is outside of buffer bounds');let t;return r===void 0&&e===void 0?t=new h(o):e===void 0?t=new h(o,r):t=new h(o,r,e),Object.setPrototypeOf(t,c.prototype),t}function D(o){if(c.isBuffer(o)){const r=Z(o.length)|0,e=M(r);return e.length===0||o.copy(e,0,0,r),e}if(o.length!==void 0)return typeof o.length!="number"||Oe(o.length)?M(0):A(o);if(o.type==="Buffer"&&Array.isArray(o.data))return A(o.data)}function Z(o){if(o>=p)throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x"+p.toString(16)+" bytes");return o|0}function F(o){return+o!=o&&(o=0),c.alloc(+o)}c.isBuffer=function(r){return r!=null&&r._isBuffer===!0&&r!==c.prototype},c.compare=function(r,e){if(V(r,h)&&(r=c.from(r,r.offset,r.byteLength)),V(e,h)&&(e=c.from(e,e.offset,e.byteLength)),!c.isBuffer(r)||!c.isBuffer(e))throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');if(r===e)return 0;let t=r.length,s=e.length;for(let f=0,d=Math.min(t,s);f<d;++f)if(r[f]!==e[f]){t=r[f],s=e[f];break}return t<s?-1:s<t?1:0},c.isEncoding=function(r){switch(String(r).toLowerCase()){case"hex":case"utf8":case"utf-8":case"ascii":case"latin1":case"binary":case"base64":case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return!0;default:return!1}},c.concat=function(r,e){if(!Array.isArray(r))throw new TypeError('"list" argument must be an Array of Buffers');if(r.length===0)return c.alloc(0);let t;if(e===void 0)for(e=0,t=0;t<r.length;++t)e+=r[t].length;const s=c.allocUnsafe(e);let f=0;for(t=0;t<r.length;++t){let d=r[t];if(V(d,h))f+d.length>s.length?(c.isBuffer(d)||(d=c.from(d)),d.copy(s,f)):h.prototype.set.call(s,d,f);else if(c.isBuffer(d))d.copy(s,f);else throw new TypeError('"list" argument must be an Array of Buffers');f+=d.length}return s};function W(o,r){if(c.isBuffer(o))return o.length;if(l.isView(o)||V(o,l))return o.byteLength;if(typeof o!="string")throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type '+typeof o);const e=o.length,t=arguments.length>2&&arguments[2]===!0;if(!t&&e===0)return 0;let s=!1;for(;;)switch(r){case"ascii":case"latin1":case"binary":return e;case"utf8":case"utf-8":return ve(o).length;case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return e*2;case"hex":return e>>>1;case"base64":return Ge(o).length;default:if(s)return t?-1:ve(o).length;r=(""+r).toLowerCase(),s=!0}}c.byteLength=W;function K(o,r,e){let t=!1;if((r===void 0||r<0)&&(r=0),r>this.length||((e===void 0||e>this.length)&&(e=this.length),e<=0)||(e>>>=0,r>>>=0,e<=r))return"";for(o||(o="utf8");;)switch(o){case"hex":return Fe(this,r,e);case"utf8":case"utf-8":return Y(this,r,e);case"ascii":return Te(this,r,e);case"latin1":case"binary":return Re(this,r,e);case"base64":return U(this,r,e);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return B(this,r,e);default:if(t)throw new TypeError("Unknown encoding: "+o);o=(o+"").toLowerCase(),t=!0}}c.prototype._isBuffer=!0;function P(o,r,e){const t=o[r];o[r]=o[e],o[e]=t}c.prototype.swap16=function(){const r=this.length;if(r%2!==0)throw new RangeError("Buffer size must be a multiple of 16-bits");for(let e=0;e<r;e+=2)P(this,e,e+1);return this},c.prototype.swap32=function(){const r=this.length;if(r%4!==0)throw new RangeError("Buffer size must be a multiple of 32-bits");for(let e=0;e<r;e+=4)P(this,e,e+3),P(this,e+1,e+2);return this},c.prototype.swap64=function(){const r=this.length;if(r%8!==0)throw new RangeError("Buffer size must be a multiple of 64-bits");for(let e=0;e<r;e+=8)P(this,e,e+7),P(this,e+1,e+6),P(this,e+2,e+5),P(this,e+3,e+4);return this},c.prototype.toString=function(){const r=this.length;return r===0?"":arguments.length===0?Y(this,0,r):K.apply(this,arguments)},c.prototype.toLocaleString=c.prototype.toString,c.prototype.equals=function(r){if(!c.isBuffer(r))throw new TypeError("Argument must be a Buffer");return this===r?!0:c.compare(this,r)===0},c.prototype.inspect=function(){let r="";const e=u.INSPECT_MAX_BYTES;return r=this.toString("hex",0,e).replace(/(.{2})/g,"$1 ").trim(),this.length>e&&(r+=" ... "),"<Buffer "+r+">"},a&&(c.prototype[a]=c.prototype.inspect),c.prototype.compare=function(r,e,t,s,f){if(V(r,h)&&(r=c.from(r,r.offset,r.byteLength)),!c.isBuffer(r))throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type '+typeof r);if(e===void 0&&(e=0),t===void 0&&(t=r?r.length:0),s===void 0&&(s=0),f===void 0&&(f=this.length),e<0||t>r.length||s<0||f>this.length)throw new RangeError("out of range index");if(s>=f&&e>=t)return 0;if(s>=f)return-1;if(e>=t)return 1;if(e>>>=0,t>>>=0,s>>>=0,f>>>=0,this===r)return 0;let d=f-s,I=t-e;const O=Math.min(d,I),S=this.slice(s,f),v=r.slice(e,t);for(let g=0;g<O;++g)if(S[g]!==v[g]){d=S[g],I=v[g];break}return d<I?-1:I<d?1:0};function he(o,r,e,t,s){if(o.length===0)return-1;if(typeof e=="string"?(t=e,e=0):e>2147483647?e=2147483647:e<-2147483648&&(e=-2147483648),e=+e,Oe(e)&&(e=s?0:o.length-1),e<0&&(e=o.length+e),e>=o.length){if(s)return-1;e=o.length-1}else if(e<0)if(s)e=0;else return-1;if(typeof r=="string"&&(r=c.from(r,t)),c.isBuffer(r))return r.length===0?-1:ue(o,r,e,t,s);if(typeof r=="number")return r=r&255,typeof h.prototype.indexOf=="function"?s?h.prototype.indexOf.call(o,r,e):h.prototype.lastIndexOf.call(o,r,e):ue(o,[r],e,t,s);throw new TypeError("val must be string, number or Buffer")}function ue(o,r,e,t,s){let f=1,d=o.length,I=r.length;if(t!==void 0&&(t=String(t).toLowerCase(),t==="ucs2"||t==="ucs-2"||t==="utf16le"||t==="utf-16le")){if(o.length<2||r.length<2)return-1;f=2,d/=2,I/=2,e/=2}function O(v,g){return f===1?v[g]:v.readUInt16BE(g*f)}let S;if(s){let v=-1;for(S=e;S<d;S++)if(O(o,S)===O(r,v===-1?0:S-v)){if(v===-1&&(v=S),S-v+1===I)return v*f}else v!==-1&&(S-=S-v),v=-1}else for(e+I>d&&(e=d-I),S=e;S>=0;S--){let v=!0;for(let g=0;g<I;g++)if(O(o,S+g)!==O(r,g)){v=!1;break}if(v)return S}return-1}c.prototype.includes=function(r,e,t){return this.indexOf(r,e,t)!==-1},c.prototype.indexOf=function(r,e,t){return he(this,r,e,t,!0)},c.prototype.lastIndexOf=function(r,e,t){return he(this,r,e,t,!1)};function le(o,r,e,t){e=Number(e)||0;const s=o.length-e;t?(t=Number(t),t>s&&(t=s)):t=s;const f=r.length;t>f/2&&(t=f/2);let d;for(d=0;d<t;++d){const I=parseInt(r.substr(d*2,2),16);if(Oe(I))return d;o[e+d]=I}return d}function de(o,r,e,t){return ge(ve(r,o.length-e),o,e,t)}function ye(o,r,e,t){return ge(je(r),o,e,t)}function me(o,r,e,t){return ge(Ge(r),o,e,t)}function oe(o,r,e,t){return ge(Be(r,o.length-e),o,e,t)}c.prototype.write=function(r,e,t,s){if(e===void 0)s="utf8",t=this.length,e=0;else if(t===void 0&&typeof e=="string")s=e,t=this.length,e=0;else if(isFinite(e))e=e>>>0,isFinite(t)?(t=t>>>0,s===void 0&&(s="utf8")):(s=t,t=void 0);else throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");const f=this.length-e;if((t===void 0||t>f)&&(t=f),r.length>0&&(t<0||e<0)||e>this.length)throw new RangeError("Attempt to write outside buffer bounds");s||(s="utf8");let d=!1;for(;;)switch(s){case"hex":return le(this,r,e,t);case"utf8":case"utf-8":return de(this,r,e,t);case"ascii":case"latin1":case"binary":return ye(this,r,e,t);case"base64":return me(this,r,e,t);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return oe(this,r,e,t);default:if(d)throw new TypeError("Unknown encoding: "+s);s=(""+s).toLowerCase(),d=!0}},c.prototype.toJSON=function(){return{type:"Buffer",data:Array.prototype.slice.call(this._arr||this,0)}};function U(o,r,e){return r===0&&e===o.length?n.fromByteArray(o):n.fromByteArray(o.slice(r,e))}function Y(o,r,e){e=Math.min(o.length,e);const t=[];let s=r;for(;s<e;){const f=o[s];let d=null,I=f>239?4:f>223?3:f>191?2:1;if(s+I<=e){let O,S,v,g;switch(I){case 1:f<128&&(d=f);break;case 2:O=o[s+1],(O&192)===128&&(g=(f&31)<<6|O&63,g>127&&(d=g));break;case 3:O=o[s+1],S=o[s+2],(O&192)===128&&(S&192)===128&&(g=(f&15)<<12|(O&63)<<6|S&63,g>2047&&(g<55296||g>57343)&&(d=g));break;case 4:O=o[s+1],S=o[s+2],v=o[s+3],(O&192)===128&&(S&192)===128&&(v&192)===128&&(g=(f&15)<<18|(O&63)<<12|(S&63)<<6|v&63,g>65535&&g<1114112&&(d=g))}}d===null?(d=65533,I=1):d>65535&&(d-=65536,t.push(d>>>10&1023|55296),d=56320|d&1023),t.push(d),s+=I}return Ce(t)}const Me=4096;function Ce(o){const r=o.length;if(r<=Me)return String.fromCharCode.apply(String,o);let e="",t=0;for(;t<r;)e+=String.fromCharCode.apply(String,o.slice(t,t+=Me));return e}function Te(o,r,e){let t="";e=Math.min(o.length,e);for(let s=r;s<e;++s)t+=String.fromCharCode(o[s]&127);return t}function Re(o,r,e){let t="";e=Math.min(o.length,e);for(let s=r;s<e;++s)t+=String.fromCharCode(o[s]);return t}function Fe(o,r,e){const t=o.length;(!r||r<0)&&(r=0),(!e||e<0||e>t)&&(e=t);let s="";for(let f=r;f<e;++f)s+=ce[o[f]];return s}function B(o,r,e){const t=o.slice(r,e);let s="";for(let f=0;f<t.length-1;f+=2)s+=String.fromCharCode(t[f]+t[f+1]*256);return s}c.prototype.slice=function(r,e){const t=this.length;r=~~r,e=e===void 0?t:~~e,r<0?(r+=t,r<0&&(r=0)):r>t&&(r=t),e<0?(e+=t,e<0&&(e=0)):e>t&&(e=t),e<r&&(e=r);const s=this.subarray(r,e);return Object.setPrototypeOf(s,c.prototype),s};function q(o,r,e){if(o%1!==0||o<0)throw new RangeError("offset is not uint");if(o+r>e)throw new RangeError("Trying to access beyond buffer length")}c.prototype.readUintLE=c.prototype.readUIntLE=function(r,e,t){r=r>>>0,e=e>>>0,t||q(r,e,this.length);let s=this[r],f=1,d=0;for(;++d<e&&(f*=256);)s+=this[r+d]*f;return s},c.prototype.readUintBE=c.prototype.readUIntBE=function(r,e,t){r=r>>>0,e=e>>>0,t||q(r,e,this.length);let s=this[r+--e],f=1;for(;e>0&&(f*=256);)s+=this[r+--e]*f;return s},c.prototype.readUint8=c.prototype.readUInt8=function(r,e){return r=r>>>0,e||q(r,1,this.length),this[r]},c.prototype.readUint16LE=c.prototype.readUInt16LE=function(r,e){return r=r>>>0,e||q(r,2,this.length),this[r]|this[r+1]<<8},c.prototype.readUint16BE=c.prototype.readUInt16BE=function(r,e){return r=r>>>0,e||q(r,2,this.length),this[r]<<8|this[r+1]},c.prototype.readUint32LE=c.prototype.readUInt32LE=function(r,e){return r=r>>>0,e||q(r,4,this.length),(this[r]|this[r+1]<<8|this[r+2]<<16)+this[r+3]*16777216},c.prototype.readUint32BE=c.prototype.readUInt32BE=function(r,e){return r=r>>>0,e||q(r,4,this.length),this[r]*16777216+(this[r+1]<<16|this[r+2]<<8|this[r+3])},c.prototype.readBigUInt64LE=ne(function(r){r=r>>>0,te(r,"offset");const e=this[r],t=this[r+7];(e===void 0||t===void 0)&&ae(r,this.length-8);const s=e+this[++r]*2**8+this[++r]*2**16+this[++r]*2**24,f=this[++r]+this[++r]*2**8+this[++r]*2**16+t*2**24;return BigInt(s)+(BigInt(f)<<BigInt(32))}),c.prototype.readBigUInt64BE=ne(function(r){r=r>>>0,te(r,"offset");const e=this[r],t=this[r+7];(e===void 0||t===void 0)&&ae(r,this.length-8);const s=e*2**24+this[++r]*2**16+this[++r]*2**8+this[++r],f=this[++r]*2**24+this[++r]*2**16+this[++r]*2**8+t;return(BigInt(s)<<BigInt(32))+BigInt(f)}),c.prototype.readIntLE=function(r,e,t){r=r>>>0,e=e>>>0,t||q(r,e,this.length);let s=this[r],f=1,d=0;for(;++d<e&&(f*=256);)s+=this[r+d]*f;return f*=128,s>=f&&(s-=Math.pow(2,8*e)),s},c.prototype.readIntBE=function(r,e,t){r=r>>>0,e=e>>>0,t||q(r,e,this.length);let s=e,f=1,d=this[r+--s];for(;s>0&&(f*=256);)d+=this[r+--s]*f;return f*=128,d>=f&&(d-=Math.pow(2,8*e)),d},c.prototype.readInt8=function(r,e){return r=r>>>0,e||q(r,1,this.length),this[r]&128?(255-this[r]+1)*-1:this[r]},c.prototype.readInt16LE=function(r,e){r=r>>>0,e||q(r,2,this.length);const t=this[r]|this[r+1]<<8;return t&32768?t|4294901760:t},c.prototype.readInt16BE=function(r,e){r=r>>>0,e||q(r,2,this.length);const t=this[r+1]|this[r]<<8;return t&32768?t|4294901760:t},c.prototype.readInt32LE=function(r,e){return r=r>>>0,e||q(r,4,this.length),this[r]|this[r+1]<<8|this[r+2]<<16|this[r+3]<<24},c.prototype.readInt32BE=function(r,e){return r=r>>>0,e||q(r,4,this.length),this[r]<<24|this[r+1]<<16|this[r+2]<<8|this[r+3]},c.prototype.readBigInt64LE=ne(function(r){r=r>>>0,te(r,"offset");const e=this[r],t=this[r+7];(e===void 0||t===void 0)&&ae(r,this.length-8);const s=this[r+4]+this[r+5]*2**8+this[r+6]*2**16+(t<<24);return(BigInt(s)<<BigInt(32))+BigInt(e+this[++r]*2**8+this[++r]*2**16+this[++r]*2**24)}),c.prototype.readBigInt64BE=ne(function(r){r=r>>>0,te(r,"offset");const e=this[r],t=this[r+7];(e===void 0||t===void 0)&&ae(r,this.length-8);const s=(e<<24)+this[++r]*2**16+this[++r]*2**8+this[++r];return(BigInt(s)<<BigInt(32))+BigInt(this[++r]*2**24+this[++r]*2**16+this[++r]*2**8+t)}),c.prototype.readFloatLE=function(r,e){return r=r>>>0,e||q(r,4,this.length),i.read(this,r,!0,23,4)},c.prototype.readFloatBE=function(r,e){return r=r>>>0,e||q(r,4,this.length),i.read(this,r,!1,23,4)},c.prototype.readDoubleLE=function(r,e){return r=r>>>0,e||q(r,8,this.length),i.read(this,r,!0,52,8)},c.prototype.readDoubleBE=function(r,e){return r=r>>>0,e||q(r,8,this.length),i.read(this,r,!1,52,8)};function H(o,r,e,t,s,f){if(!c.isBuffer(o))throw new TypeError('"buffer" argument must be a Buffer instance');if(r>s||r<f)throw new RangeError('"value" argument is out of bounds');if(e+t>o.length)throw new RangeError("Index out of range")}c.prototype.writeUintLE=c.prototype.writeUIntLE=function(r,e,t,s){if(r=+r,e=e>>>0,t=t>>>0,!s){const I=Math.pow(2,8*t)-1;H(this,r,e,t,I,0)}let f=1,d=0;for(this[e]=r&255;++d<t&&(f*=256);)this[e+d]=r/f&255;return e+t},c.prototype.writeUintBE=c.prototype.writeUIntBE=function(r,e,t,s){if(r=+r,e=e>>>0,t=t>>>0,!s){const I=Math.pow(2,8*t)-1;H(this,r,e,t,I,0)}let f=t-1,d=1;for(this[e+f]=r&255;--f>=0&&(d*=256);)this[e+f]=r/d&255;return e+t},c.prototype.writeUint8=c.prototype.writeUInt8=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,1,255,0),this[e]=r&255,e+1},c.prototype.writeUint16LE=c.prototype.writeUInt16LE=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,2,65535,0),this[e]=r&255,this[e+1]=r>>>8,e+2},c.prototype.writeUint16BE=c.prototype.writeUInt16BE=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,2,65535,0),this[e]=r>>>8,this[e+1]=r&255,e+2},c.prototype.writeUint32LE=c.prototype.writeUInt32LE=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,4,4294967295,0),this[e+3]=r>>>24,this[e+2]=r>>>16,this[e+1]=r>>>8,this[e]=r&255,e+4},c.prototype.writeUint32BE=c.prototype.writeUInt32BE=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,4,4294967295,0),this[e]=r>>>24,this[e+1]=r>>>16,this[e+2]=r>>>8,this[e+3]=r&255,e+4};function G(o,r,e,t,s){Ue(r,t,s,o,e,7);let f=Number(r&BigInt(4294967295));o[e++]=f,f=f>>8,o[e++]=f,f=f>>8,o[e++]=f,f=f>>8,o[e++]=f;let d=Number(r>>BigInt(32)&BigInt(4294967295));return o[e++]=d,d=d>>8,o[e++]=d,d=d>>8,o[e++]=d,d=d>>8,o[e++]=d,e}function Pe(o,r,e,t,s){Ue(r,t,s,o,e,7);let f=Number(r&BigInt(4294967295));o[e+7]=f,f=f>>8,o[e+6]=f,f=f>>8,o[e+5]=f,f=f>>8,o[e+4]=f;let d=Number(r>>BigInt(32)&BigInt(4294967295));return o[e+3]=d,d=d>>8,o[e+2]=d,d=d>>8,o[e+1]=d,d=d>>8,o[e]=d,e+8}c.prototype.writeBigUInt64LE=ne(function(r,e=0){return G(this,r,e,BigInt(0),BigInt("0xffffffffffffffff"))}),c.prototype.writeBigUInt64BE=ne(function(r,e=0){return Pe(this,r,e,BigInt(0),BigInt("0xffffffffffffffff"))}),c.prototype.writeIntLE=function(r,e,t,s){if(r=+r,e=e>>>0,!s){const O=Math.pow(2,8*t-1);H(this,r,e,t,O-1,-O)}let f=0,d=1,I=0;for(this[e]=r&255;++f<t&&(d*=256);)r<0&&I===0&&this[e+f-1]!==0&&(I=1),this[e+f]=(r/d>>0)-I&255;return e+t},c.prototype.writeIntBE=function(r,e,t,s){if(r=+r,e=e>>>0,!s){const O=Math.pow(2,8*t-1);H(this,r,e,t,O-1,-O)}let f=t-1,d=1,I=0;for(this[e+f]=r&255;--f>=0&&(d*=256);)r<0&&I===0&&this[e+f+1]!==0&&(I=1),this[e+f]=(r/d>>0)-I&255;return e+t},c.prototype.writeInt8=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,1,127,-128),r<0&&(r=255+r+1),this[e]=r&255,e+1},c.prototype.writeInt16LE=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,2,32767,-32768),this[e]=r&255,this[e+1]=r>>>8,e+2},c.prototype.writeInt16BE=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,2,32767,-32768),this[e]=r>>>8,this[e+1]=r&255,e+2},c.prototype.writeInt32LE=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,4,2147483647,-2147483648),this[e]=r&255,this[e+1]=r>>>8,this[e+2]=r>>>16,this[e+3]=r>>>24,e+4},c.prototype.writeInt32BE=function(r,e,t){return r=+r,e=e>>>0,t||H(this,r,e,4,2147483647,-2147483648),r<0&&(r=4294967295+r+1),this[e]=r>>>24,this[e+1]=r>>>16,this[e+2]=r>>>8,this[e+3]=r&255,e+4},c.prototype.writeBigInt64LE=ne(function(r,e=0){return G(this,r,e,-BigInt("0x8000000000000000"),BigInt("0x7fffffffffffffff"))}),c.prototype.writeBigInt64BE=ne(function(r,e=0){return Pe(this,r,e,-BigInt("0x8000000000000000"),BigInt("0x7fffffffffffffff"))});function Ne(o,r,e,t,s,f){if(e+t>o.length)throw new RangeError("Index out of range");if(e<0)throw new RangeError("Index out of range")}function Ae(o,r,e,t,s){return r=+r,e=e>>>0,s||Ne(o,r,e,4),i.write(o,r,e,t,23,4),e+4}c.prototype.writeFloatLE=function(r,e,t){return Ae(this,r,e,!0,t)},c.prototype.writeFloatBE=function(r,e,t){return Ae(this,r,e,!1,t)};function $e(o,r,e,t,s){return r=+r,e=e>>>0,s||Ne(o,r,e,8),i.write(o,r,e,t,52,8),e+8}c.prototype.writeDoubleLE=function(r,e,t){return $e(this,r,e,!0,t)},c.prototype.writeDoubleBE=function(r,e,t){return $e(this,r,e,!1,t)},c.prototype.copy=function(r,e,t,s){if(!c.isBuffer(r))throw new TypeError("argument should be a Buffer");if(t||(t=0),!s&&s!==0&&(s=this.length),e>=r.length&&(e=r.length),e||(e=0),s>0&&s<t&&(s=t),s===t||r.length===0||this.length===0)return 0;if(e<0)throw new RangeError("targetStart out of bounds");if(t<0||t>=this.length)throw new RangeError("Index out of range");if(s<0)throw new RangeError("sourceEnd out of bounds");s>this.length&&(s=this.length),r.length-e<s-t&&(s=r.length-e+t);const f=s-t;return this===r&&typeof h.prototype.copyWithin=="function"?this.copyWithin(e,t,s):h.prototype.set.call(r,this.subarray(t,s),e),f},c.prototype.fill=function(r,e,t,s){if(typeof r=="string"){if(typeof e=="string"?(s=e,e=0,t=this.length):typeof t=="string"&&(s=t,t=this.length),s!==void 0&&typeof s!="string")throw new TypeError("encoding must be a string");if(typeof s=="string"&&!c.isEncoding(s))throw new TypeError("Unknown encoding: "+s);if(r.length===1){const d=r.charCodeAt(0);(s==="utf8"&&d<128||s==="latin1")&&(r=d)}}else typeof r=="number"?r=r&255:typeof r=="boolean"&&(r=Number(r));if(e<0||this.length<e||this.length<t)throw new RangeError("Out of range index");if(t<=e)return this;e=e>>>0,t=t===void 0?this.length:t>>>0,r||(r=0);let f;if(typeof r=="number")for(f=e;f<t;++f)this[f]=r;else{const d=c.isBuffer(r)?r:c.from(r,s),I=d.length;if(I===0)throw new TypeError('The value "'+r+'" is invalid for argument "value"');for(f=0;f<t-e;++f)this[f+e]=d[f%I]}return this};const z={};function we(o,r,e){z[o]=class extends e{constructor(){super(),Object.defineProperty(this,"message",{value:r.apply(this,arguments),writable:!0,configurable:!0}),this.name=`${this.name} [${o}]`,this.stack,delete this.name}get code(){return o}set code(s){Object.defineProperty(this,"code",{configurable:!0,enumerable:!0,value:s,writable:!0})}toString(){return`${this.name} [${o}]: ${this.message}`}}}we("ERR_BUFFER_OUT_OF_BOUNDS",function(o){return o?`${o} is outside of buffer bounds`:"Attempt to access memory outside buffer bounds"},RangeError),we("ERR_INVALID_ARG_TYPE",function(o,r){return`The "${o}" argument must be of type number. Received type ${typeof r}`},TypeError),we("ERR_OUT_OF_RANGE",function(o,r,e){let t=`The value of "${o}" is out of range.`,s=e;return Number.isInteger(e)&&Math.abs(e)>2**32?s=fe(String(e)):typeof e=="bigint"&&(s=String(e),(e>BigInt(2)**BigInt(32)||e<-(BigInt(2)**BigInt(32)))&&(s=fe(s)),s+="n"),t+=` It must be ${r}. Received ${s}`,t},RangeError);function fe(o){let r="",e=o.length;const t=o[0]==="-"?1:0;for(;e>=t+4;e-=3)r=`_${o.slice(e-3,e)}${r}`;return`${o.slice(0,e)}${r}`}function ke(o,r,e){te(r,"offset"),(o[r]===void 0||o[r+e]===void 0)&&ae(r,o.length-(e+1))}function Ue(o,r,e,t,s,f){if(o>e||o<r){const d=typeof r=="bigint"?"n":"";let I;throw r===0||r===BigInt(0)?I=`>= 0${d} and < 2${d} ** ${(f+1)*8}${d}`:I=`>= -(2${d} ** ${(f+1)*8-1}${d}) and < 2 ** ${(f+1)*8-1}${d}`,new z.ERR_OUT_OF_RANGE("value",I,o)}ke(t,s,f)}function te(o,r){if(typeof o!="number")throw new z.ERR_INVALID_ARG_TYPE(r,"number",o)}function ae(o,r,e){throw Math.floor(o)!==o?(te(o,e),new z.ERR_OUT_OF_RANGE("offset","an integer",o)):r<0?new z.ERR_BUFFER_OUT_OF_BOUNDS:new z.ERR_OUT_OF_RANGE("offset",`>= 0 and <= ${r}`,o)}const De=/[^+/0-9A-Za-z-_]/g;function qe(o){if(o=o.split("=")[0],o=o.trim().replace(De,""),o.length<2)return"";for(;o.length%4!==0;)o=o+"=";return o}function ve(o,r){r=r||1/0;let e;const t=o.length;let s=null;const f=[];for(let d=0;d<t;++d){if(e=o.charCodeAt(d),e>55295&&e<57344){if(!s){if(e>56319){(r-=3)>-1&&f.push(239,191,189);continue}else if(d+1===t){(r-=3)>-1&&f.push(239,191,189);continue}s=e;continue}if(e<56320){(r-=3)>-1&&f.push(239,191,189),s=e;continue}e=(s-55296<<10|e-56320)+65536}else s&&(r-=3)>-1&&f.push(239,191,189);if(s=null,e<128){if((r-=1)<0)break;f.push(e)}else if(e<2048){if((r-=2)<0)break;f.push(e>>6|192,e&63|128)}else if(e<65536){if((r-=3)<0)break;f.push(e>>12|224,e>>6&63|128,e&63|128)}else if(e<1114112){if((r-=4)<0)break;f.push(e>>18|240,e>>12&63|128,e>>6&63|128,e&63|128)}else throw new Error("Invalid code point")}return f}function je(o){const r=[];for(let e=0;e<o.length;++e)r.push(o.charCodeAt(e)&255);return r}function Be(o,r){let e,t,s;const f=[];for(let d=0;d<o.length&&!((r-=2)<0);++d)e=o.charCodeAt(d),t=e>>8,s=e%256,f.push(s),f.push(t);return f}function Ge(o){return n.toByteArray(qe(o))}function ge(o,r,e,t){let s;for(s=0;s<t&&!(s+e>=r.length||s>=o.length);++s)r[s+e]=o[s];return s}function V(o,r){return o instanceof r||o!=null&&o.constructor!=null&&o.constructor.name!=null&&o.constructor.name===r.name}function Oe(o){return o!==o}const ce=function(){const o="0123456789abcdef",r=new Array(256);for(let e=0;e<16;++e){const t=e*16;for(let s=0;s<16;++s)r[t+s]=o[e]+o[s]}return r}();function ne(o){return typeof BigInt>"u"?Je:o}function Je(){throw new Error("BigInt not supported")}})(vt);const Qe=vt.Buffer;var C;(function(u){u[u.PLAIN_TO_CLASS=0]="PLAIN_TO_CLASS",u[u.CLASS_TO_PLAIN=1]="CLASS_TO_PLAIN",u[u.CLASS_TO_CLASS=2]="CLASS_TO_CLASS"})(C||(C={}));var Wt=function(){function u(){this._typeMetadatas=new Map,this._transformMetadatas=new Map,this._exposeMetadatas=new Map,this._excludeMetadatas=new Map,this._ancestorsMap=new Map}return u.prototype.addTypeMetadata=function(n){this._typeMetadatas.has(n.target)||this._typeMetadatas.set(n.target,new Map),this._typeMetadatas.get(n.target).set(n.propertyName,n)},u.prototype.addTransformMetadata=function(n){this._transformMetadatas.has(n.target)||this._transformMetadatas.set(n.target,new Map),this._transformMetadatas.get(n.target).has(n.propertyName)||this._transformMetadatas.get(n.target).set(n.propertyName,[]),this._transformMetadatas.get(n.target).get(n.propertyName).push(n)},u.prototype.addExposeMetadata=function(n){this._exposeMetadatas.has(n.target)||this._exposeMetadatas.set(n.target,new Map),this._exposeMetadatas.get(n.target).set(n.propertyName,n)},u.prototype.addExcludeMetadata=function(n){this._excludeMetadatas.has(n.target)||this._excludeMetadatas.set(n.target,new Map),this._excludeMetadatas.get(n.target).set(n.propertyName,n)},u.prototype.findTransformMetadatas=function(n,i,a){return this.findMetadatas(this._transformMetadatas,n,i).filter(function(p){return!p.options||p.options.toClassOnly===!0&&p.options.toPlainOnly===!0?!0:p.options.toClassOnly===!0?a===C.CLASS_TO_CLASS||a===C.PLAIN_TO_CLASS:p.options.toPlainOnly===!0?a===C.CLASS_TO_PLAIN:!0})},u.prototype.findExcludeMetadata=function(n,i){return this.findMetadata(this._excludeMetadatas,n,i)},u.prototype.findExposeMetadata=function(n,i){return this.findMetadata(this._exposeMetadatas,n,i)},u.prototype.findExposeMetadataByCustomName=function(n,i){return this.getExposedMetadatas(n).find(function(a){return a.options&&a.options.name===i})},u.prototype.findTypeMetadata=function(n,i){return this.findMetadata(this._typeMetadatas,n,i)},u.prototype.getStrategy=function(n){var i=this._excludeMetadatas.get(n),a=i&&i.get(void 0),p=this._exposeMetadatas.get(n),h=p&&p.get(void 0);return a&&h||!a&&!h?"none":a?"excludeAll":"exposeAll"},u.prototype.getExposedMetadatas=function(n){return this.getMetadata(this._exposeMetadatas,n)},u.prototype.getExcludedMetadatas=function(n){return this.getMetadata(this._excludeMetadatas,n)},u.prototype.getExposedProperties=function(n,i){return this.getExposedMetadatas(n).filter(function(a){return!a.options||a.options.toClassOnly===!0&&a.options.toPlainOnly===!0?!0:a.options.toClassOnly===!0?i===C.CLASS_TO_CLASS||i===C.PLAIN_TO_CLASS:a.options.toPlainOnly===!0?i===C.CLASS_TO_PLAIN:!0}).map(function(a){return a.propertyName})},u.prototype.getExcludedProperties=function(n,i){return this.getExcludedMetadatas(n).filter(function(a){return!a.options||a.options.toClassOnly===!0&&a.options.toPlainOnly===!0?!0:a.options.toClassOnly===!0?i===C.CLASS_TO_CLASS||i===C.PLAIN_TO_CLASS:a.options.toPlainOnly===!0?i===C.CLASS_TO_PLAIN:!0}).map(function(a){return a.propertyName})},u.prototype.clear=function(){this._typeMetadatas.clear(),this._exposeMetadatas.clear(),this._excludeMetadatas.clear(),this._ancestorsMap.clear()},u.prototype.getMetadata=function(n,i){var a=n.get(i),p;a&&(p=Array.from(a.values()).filter(function(_){return _.propertyName!==void 0}));for(var h=[],l=0,y=this.getAncestors(i);l<y.length;l++){var w=y[l],M=n.get(w);if(M){var c=Array.from(M.values()).filter(function(_){return _.propertyName!==void 0});h.push.apply(h,c)}}return h.concat(p||[])},u.prototype.findMetadata=function(n,i,a){var p=n.get(i);if(p){var h=p.get(a);if(h)return h}for(var l=0,y=this.getAncestors(i);l<y.length;l++){var w=y[l],M=n.get(w);if(M){var c=M.get(a);if(c)return c}}},u.prototype.findMetadatas=function(n,i,a){var p=n.get(i),h;p&&(h=p.get(a));for(var l=[],y=0,w=this.getAncestors(i);y<w.length;y++){var M=w[y],c=n.get(M);c&&c.has(a)&&l.push.apply(l,c.get(a))}return l.slice().reverse().concat((h||[]).slice().reverse())},u.prototype.getAncestors=function(n){if(!n)return[];if(!this._ancestorsMap.has(n)){for(var i=[],a=Object.getPrototypeOf(n.prototype.constructor);typeof a.prototype<"u";a=Object.getPrototypeOf(a.prototype.constructor))i.push(a);this._ancestorsMap.set(n,i)}return this._ancestorsMap.get(n)},u}(),J=new Wt;function Xt(){if(typeof globalThis<"u")return globalThis;if(typeof Fr<"u")return Fr;if(typeof window<"u")return window;if(typeof self<"u")return self}function zt(u){return u!==null&&typeof u=="object"&&typeof u.then=="function"}var $r=function(u,n,i){if(i||arguments.length===2)for(var a=0,p=n.length,h;a<p;a++)(h||!(a in n))&&(h||(h=Array.prototype.slice.call(n,0,a)),h[a]=n[a]);return u.concat(h||Array.prototype.slice.call(n))};function Zt(u){var n=new u;return!(n instanceof Set)&&!("push"in n)?[]:n}var _e=function(){function u(n,i){this.transformationType=n,this.options=i,this.recursionStack=new Set}return u.prototype.transform=function(n,i,a,p,h,l){var y=this;if(l===void 0&&(l=0),Array.isArray(i)||i instanceof Set){var w=p&&this.transformationType===C.PLAIN_TO_CLASS?Zt(p):[];return i.forEach(function(A,R){var k=n?n[R]:void 0;if(!y.options.enableCircularCheck||!y.isCircular(A)){var D=void 0;if(typeof a!="function"&&a&&a.options&&a.options.discriminator&&a.options.discriminator.property&&a.options.discriminator.subTypes){if(y.transformationType===C.PLAIN_TO_CLASS){D=a.options.discriminator.subTypes.find(function(K){return K.name===A[a.options.discriminator.property]});var Z={newObject:w,object:A,property:void 0},F=a.typeFunction(Z);D===void 0?D=F:D=D.value,a.options.keepDiscriminatorProperty||delete A[a.options.discriminator.property]}y.transformationType===C.CLASS_TO_CLASS&&(D=A.constructor),y.transformationType===C.CLASS_TO_PLAIN&&(A[a.options.discriminator.property]=a.options.discriminator.subTypes.find(function(K){return K.value===A.constructor}).name)}else D=a;var W=y.transform(k,A,D,void 0,A instanceof Map,l+1);w instanceof Set?w.add(W):w.push(W)}else y.transformationType===C.CLASS_TO_CLASS&&(w instanceof Set?w.add(A):w.push(A))}),w}else{if(a===String&&!h)return i==null?i:String(i);if(a===Number&&!h)return i==null?i:Number(i);if(a===Boolean&&!h)return i==null?i:!!i;if((a===Date||i instanceof Date)&&!h)return i instanceof Date?new Date(i.valueOf()):i==null?i:new Date(i);if(Xt().Buffer&&(a===Qe||i instanceof Qe)&&!h)return i==null?i:Qe.from(i);if(zt(i)&&!h)return new Promise(function(A,R){i.then(function(k){return A(y.transform(void 0,k,a,void 0,void 0,l+1))},R)});if(!h&&i!==null&&typeof i=="object"&&typeof i.then=="function")return i;if(typeof i=="object"&&i!==null){!a&&i.constructor!==Object&&(!Array.isArray(i)&&i.constructor===Array||(a=i.constructor)),!a&&n&&(a=n.constructor),this.options.enableCircularCheck&&this.recursionStack.add(i);var M=this.getKeys(a,i,h),c=n||{};!n&&(this.transformationType===C.PLAIN_TO_CLASS||this.transformationType===C.CLASS_TO_CLASS)&&(h?c=new Map:a?c=new a:c={});for(var _=function(A){if(A==="__proto__"||A==="constructor")return"continue";var R=A,k=A,D=A;if(!x.options.ignoreDecorators&&a){if(x.transformationType===C.PLAIN_TO_CLASS){var Z=J.findExposeMetadataByCustomName(a,A);Z&&(D=Z.propertyName,k=Z.propertyName)}else if(x.transformationType===C.CLASS_TO_PLAIN||x.transformationType===C.CLASS_TO_CLASS){var Z=J.findExposeMetadata(a,A);Z&&Z.options&&Z.options.name&&(k=Z.options.name)}}var F=void 0;x.transformationType===C.PLAIN_TO_CLASS?F=i[R]:i instanceof Map?F=i.get(R):i[R]instanceof Function?F=i[R]():F=i[R];var W=void 0,K=F instanceof Map;if(a&&h)W=a;else if(a){var P=J.findTypeMetadata(a,D);if(P){var he={newObject:c,object:i,property:D},ue=P.typeFunction?P.typeFunction(he):P.reflectedType;P.options&&P.options.discriminator&&P.options.discriminator.property&&P.options.discriminator.subTypes?i[R]instanceof Array?W=P:(x.transformationType===C.PLAIN_TO_CLASS&&(W=P.options.discriminator.subTypes.find(function(Y){if(F&&F instanceof Object&&P.options.discriminator.property in F)return Y.name===F[P.options.discriminator.property]}),W===void 0?W=ue:W=W.value,P.options.keepDiscriminatorProperty||F&&F instanceof Object&&P.options.discriminator.property in F&&delete F[P.options.discriminator.property]),x.transformationType===C.CLASS_TO_CLASS&&(W=F.constructor),x.transformationType===C.CLASS_TO_PLAIN&&F&&(F[P.options.discriminator.property]=P.options.discriminator.subTypes.find(function(Y){return Y.value===F.constructor}).name)):W=ue,K=K||P.reflectedType===Map}else if(x.options.targetMaps)x.options.targetMaps.filter(function(Y){return Y.target===a&&!!Y.properties[D]}).forEach(function(Y){return W=Y.properties[D]});else if(x.options.enableImplicitConversion&&x.transformationType===C.PLAIN_TO_CLASS){var le=Reflect.getMetadata("design:type",a.prototype,D);le&&(W=le)}}var de=Array.isArray(i[R])?x.getReflectedType(a,D):void 0,ye=n?n[R]:void 0;if(c.constructor.prototype){var me=Object.getOwnPropertyDescriptor(c.constructor.prototype,k);if((x.transformationType===C.PLAIN_TO_CLASS||x.transformationType===C.CLASS_TO_CLASS)&&(me&&!me.set||c[k]instanceof Function))return"continue"}if(!x.options.enableCircularCheck||!x.isCircular(F)){var oe=x.transformationType===C.PLAIN_TO_CLASS?k:A,U=void 0;x.transformationType===C.CLASS_TO_PLAIN?(U=i[oe],U=x.applyCustomTransformations(U,a,oe,i,x.transformationType),U=i[oe]===U?F:U,U=x.transform(ye,U,W,de,K,l+1)):F===void 0&&x.options.exposeDefaultValues?U=c[k]:(U=x.transform(ye,F,W,de,K,l+1),U=x.applyCustomTransformations(U,a,oe,i,x.transformationType)),(U!==void 0||x.options.exposeUnsetFields)&&(c instanceof Map?c.set(k,U):c[k]=U)}else if(x.transformationType===C.CLASS_TO_CLASS){var U=F;U=x.applyCustomTransformations(U,a,A,i,x.transformationType),(U!==void 0||x.options.exposeUnsetFields)&&(c instanceof Map?c.set(k,U):c[k]=U)}},x=this,m=0,$=M;m<$.length;m++){var L=$[m];_(L)}return this.options.enableCircularCheck&&this.recursionStack.delete(i),c}else return i}},u.prototype.applyCustomTransformations=function(n,i,a,p,h){var l=this,y=J.findTransformMetadatas(i,a,this.transformationType);return this.options.version!==void 0&&(y=y.filter(function(w){return w.options?l.checkVersion(w.options.since,w.options.until):!0})),this.options.groups&&this.options.groups.length?y=y.filter(function(w){return w.options?l.checkGroups(w.options.groups):!0}):y=y.filter(function(w){return!w.options||!w.options.groups||!w.options.groups.length}),y.forEach(function(w){n=w.transformFn({value:n,key:a,obj:p,type:h,options:l.options})}),n},u.prototype.isCircular=function(n){return this.recursionStack.has(n)},u.prototype.getReflectedType=function(n,i){if(n){var a=J.findTypeMetadata(n,i);return a?a.reflectedType:void 0}},u.prototype.getKeys=function(n,i,a){var p=this,h=J.getStrategy(n);h==="none"&&(h=this.options.strategy||"exposeAll");var l=[];if((h==="exposeAll"||a)&&(i instanceof Map?l=Array.from(i.keys()):l=Object.keys(i)),a)return l;if(this.options.ignoreDecorators&&this.options.excludeExtraneousValues&&n){var y=J.getExposedProperties(n,this.transformationType),w=J.getExcludedProperties(n,this.transformationType);l=$r($r([],y,!0),w,!0)}if(!this.options.ignoreDecorators&&n){var y=J.getExposedProperties(n,this.transformationType);this.transformationType===C.PLAIN_TO_CLASS&&(y=y.map(function(_){var x=J.findExposeMetadata(n,_);return x&&x.options&&x.options.name?x.options.name:_})),this.options.excludeExtraneousValues?l=y:l=l.concat(y);var M=J.getExcludedProperties(n,this.transformationType);M.length>0&&(l=l.filter(function(_){return!M.includes(_)})),this.options.version!==void 0&&(l=l.filter(function(_){var x=J.findExposeMetadata(n,_);return!x||!x.options?!0:p.checkVersion(x.options.since,x.options.until)})),this.options.groups&&this.options.groups.length?l=l.filter(function(_){var x=J.findExposeMetadata(n,_);return!x||!x.options?!0:p.checkGroups(x.options.groups)}):l=l.filter(function(_){var x=J.findExposeMetadata(n,_);return!x||!x.options||!x.options.groups||!x.options.groups.length})}return this.options.excludePrefixes&&this.options.excludePrefixes.length&&(l=l.filter(function(c){return p.options.excludePrefixes.every(function(_){return c.substr(0,_.length)!==_})})),l=l.filter(function(c,_,x){return x.indexOf(c)===_}),l},u.prototype.checkVersion=function(n,i){var a=!0;return a&&n&&(a=this.options.version>=n),a&&i&&(a=this.options.version<i),a},u.prototype.checkGroups=function(n){return n?this.options.groups.some(function(i){return n.includes(i)}):!0},u}(),Ee={enableCircularCheck:!1,enableImplicitConversion:!1,excludeExtraneousValues:!1,excludePrefixes:void 0,exposeDefaultValues:!1,exposeUnsetFields:!0,groups:void 0,ignoreDecorators:!1,strategy:void 0,targetMaps:void 0,version:void 0},Q=function(){return Q=Object.assign||function(u){for(var n,i=1,a=arguments.length;i<a;i++){n=arguments[i];for(var p in n)Object.prototype.hasOwnProperty.call(n,p)&&(u[p]=n[p])}return u},Q.apply(this,arguments)},Ht=function(){function u(){}return u.prototype.instanceToPlain=function(n,i){var a=new _e(C.CLASS_TO_PLAIN,Q(Q({},Ee),i));return a.transform(void 0,n,void 0,void 0,void 0,void 0)},u.prototype.classToPlainFromExist=function(n,i,a){var p=new _e(C.CLASS_TO_PLAIN,Q(Q({},Ee),a));return p.transform(i,n,void 0,void 0,void 0,void 0)},u.prototype.plainToInstance=function(n,i,a){var p=new _e(C.PLAIN_TO_CLASS,Q(Q({},Ee),a));return p.transform(void 0,i,n,void 0,void 0,void 0)},u.prototype.plainToClassFromExist=function(n,i,a){var p=new _e(C.PLAIN_TO_CLASS,Q(Q({},Ee),a));return p.transform(n,i,void 0,void 0,void 0,void 0)},u.prototype.instanceToInstance=function(n,i){var a=new _e(C.CLASS_TO_CLASS,Q(Q({},Ee),i));return a.transform(void 0,n,void 0,void 0,void 0,void 0)},u.prototype.classToClassFromExist=function(n,i,a){var p=new _e(C.CLASS_TO_CLASS,Q(Q({},Ee),a));return p.transform(i,n,void 0,void 0,void 0,void 0)},u.prototype.serialize=function(n,i){return JSON.stringify(this.instanceToPlain(n,i))},u.prototype.deserialize=function(n,i,a){var p=JSON.parse(i);return this.plainToInstance(n,p,a)},u.prototype.deserializeArray=function(n,i,a){var p=JSON.parse(i);return this.plainToInstance(n,p,a)},u}();function Se(u,n){return n===void 0&&(n={}),function(i,a){J.addTransformMetadata({target:i.constructor,propertyName:a,transformFn:u,options:n})}}function be(u,n){return n===void 0&&(n={}),function(i,a){var p=Reflect.getMetadata("design:type",i,a);J.addTypeMetadata({target:i.constructor,propertyName:a,reflectedType:p,typeFunction:u,options:n})}}var Jt=new Ht;function Gn(u,n,i){return Jt.plainToInstance(u,n,i)}var Yt=Object.defineProperty,Ie=(u,n,i,a)=>{for(var p=void 0,h=u.length-1,l;h>=0;h--)(l=u[h])&&(p=l(n,i,p)||p);return p&&Yt(n,i,p),p};const pe=class xt{downloadSpeed;uploadSpeed;numActive;numWaiting;numStopped;numStoppedTotal;constructor(n,i,a,p,h,l){this.downloadSpeed=n,this.uploadSpeed=i,this.numActive=a,this.numWaiting=p,this.numStopped=h,this.numStoppedTotal=l}static default(){return new xt(0,0,0,0,0,0)}};Ie([be(()=>Number),Se(({value:u})=>Number.parseInt(u,10))],pe.prototype,"downloadSpeed");Ie([be(()=>Number),Se(({value:u})=>Number.parseInt(u,10))],pe.prototype,"uploadSpeed");Ie([be(()=>Number),Se(({value:u})=>Number.parseInt(u,10))],pe.prototype,"numActive");Ie([be(()=>Number),Se(({value:u})=>Number.parseInt(u,10))],pe.prototype,"numWaiting");Ie([be(()=>Number),Se(({value:u})=>Number.parseInt(u,10))],pe.prototype,"numStopped");Ie([be(()=>Number),Se(({value:u})=>Number.parseInt(u,10))],pe.prototype,"numStoppedTotal");let Wn=pe;/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Ke,kr;function Qt(){if(kr)return Ke;kr=1;var u=typeof Object.defineProperty=="function"?Object.defineProperty:null;return Ke=u,Ke}/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Ve,Ur;function Kt(){if(Ur)return Ve;Ur=1;var u=Qt();function n(){try{return u({},"x",{}),!0}catch{return!1}}return Ve=n,Ve}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var er,Dr;function Vt(){if(Dr)return er;Dr=1;var u=Object.defineProperty;return er=u,er}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var rr,qr;function _t(){if(qr)return rr;qr=1;function u(n){return typeof n=="number"}return rr=u,rr}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var tr,jr;function Et(){if(jr)return tr;jr=1;function u(a){return a[0]==="-"}function n(a){var p="",h;for(h=0;h<a;h++)p+="0";return p}function i(a,p,h){var l=!1,y=p-a.length;return y<0||(u(a)&&(l=!0,a=a.substr(1)),a=h?a+n(y):n(y)+a,l&&(a="-"+a)),a}return tr=i,tr}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var nr,Gr;function en(){if(Gr)return nr;Gr=1;var u=_t(),n=Et(),i=String.prototype.toLowerCase,a=String.prototype.toUpperCase;function p(h){var l,y,w;switch(h.specifier){case"b":l=2;break;case"o":l=8;break;case"x":case"X":l=16;break;case"d":case"i":case"u":default:l=10;break}if(y=h.arg,w=parseInt(y,10),!isFinite(w)){if(!u(y))throw new Error("invalid integer. Value: "+y);w=0}return w<0&&(h.specifier==="u"||l!==10)&&(w=4294967295+w+1),w<0?(y=(-w).toString(l),h.precision&&(y=n(y,h.precision,h.padRight)),y="-"+y):(y=w.toString(l),!w&&!h.precision?y="":h.precision&&(y=n(y,h.precision,h.padRight)),h.sign&&(y=h.sign+y)),l===16&&(h.alternate&&(y="0x"+y),y=h.specifier===a.call(h.specifier)?a.call(y):i.call(y)),l===8&&h.alternate&&y.charAt(0)!=="0"&&(y="0"+y),y}return nr=p,nr}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var ir,Wr;function rn(){if(Wr)return ir;Wr=1;function u(n){return typeof n=="string"}return ir=u,ir}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var or,Xr;function tn(){if(Xr)return or;Xr=1;var u=_t(),n=Math.abs,i=String.prototype.toLowerCase,a=String.prototype.toUpperCase,p=String.prototype.replace,h=/e\+(\d)$/,l=/e-(\d)$/,y=/^(\d+)$/,w=/^(\d+)e/,M=/\.0$/,c=/\.0*e/,_=/(\..*[^0])0*e/;function x(m){var $,L,A=parseFloat(m.arg);if(!isFinite(A)){if(!u(m.arg))throw new Error("invalid floating-point number. Value: "+L);A=m.arg}switch(m.specifier){case"e":case"E":L=A.toExponential(m.precision);break;case"f":case"F":L=A.toFixed(m.precision);break;case"g":case"G":n(A)<1e-4?($=m.precision,$>0&&($-=1),L=A.toExponential($)):L=A.toPrecision(m.precision),m.alternate||(L=p.call(L,_,"$1e"),L=p.call(L,c,"e"),L=p.call(L,M,""));break;default:throw new Error("invalid double notation. Value: "+m.specifier)}return L=p.call(L,h,"e+0$1"),L=p.call(L,l,"e-0$1"),m.alternate&&(L=p.call(L,y,"$1."),L=p.call(L,w,"$1.e")),A>=0&&m.sign&&(L=m.sign+L),L=m.specifier===a.call(m.specifier)?a.call(L):i.call(L),L}return or=x,or}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var ar,zr;function nn(){if(zr)return ar;zr=1;function u(i){var a="",p;for(p=0;p<i;p++)a+=" ";return a}function n(i,a,p){var h=a-i.length;return h<0||(i=p?i+u(h):u(h)+i),i}return ar=n,ar}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var sr,Zr;function on(){if(Zr)return sr;Zr=1;var u=en(),n=rn(),i=tn(),a=nn(),p=Et(),h=String.fromCharCode,l=Array.isArray;function y(c){return c!==c}function w(c){var _={};return _.specifier=c.specifier,_.precision=c.precision===void 0?1:c.precision,_.width=c.width,_.flags=c.flags||"",_.mapping=c.mapping,_}function M(c){var _,x,m,$,L,A,R,k,D;if(!l(c))throw new TypeError("invalid argument. First argument must be an array. Value: `"+c+"`.");for(A="",R=1,k=0;k<c.length;k++)if(m=c[k],n(m))A+=m;else{if(_=m.precision!==void 0,m=w(m),!m.specifier)throw new TypeError("invalid argument. Token is missing `specifier` property. Index: `"+k+"`. Value: `"+m+"`.");for(m.mapping&&(R=m.mapping),x=m.flags,D=0;D<x.length;D++)switch($=x.charAt(D),$){case" ":m.sign=" ";break;case"+":m.sign="+";break;case"-":m.padRight=!0,m.padZeros=!1;break;case"0":m.padZeros=x.indexOf("-")<0;break;case"#":m.alternate=!0;break;default:throw new Error("invalid flag: "+$)}if(m.width==="*"){if(m.width=parseInt(arguments[R],10),R+=1,y(m.width))throw new TypeError("the argument for * width at position "+R+" is not a number. Value: `"+m.width+"`.");m.width<0&&(m.padRight=!0,m.width=-m.width)}if(_&&m.precision==="*"){if(m.precision=parseInt(arguments[R],10),R+=1,y(m.precision))throw new TypeError("the argument for * precision at position "+R+" is not a number. Value: `"+m.precision+"`.");m.precision<0&&(m.precision=1,_=!1)}switch(m.arg=arguments[R],m.specifier){case"b":case"o":case"x":case"X":case"d":case"i":case"u":_&&(m.padZeros=!1),m.arg=u(m);break;case"s":m.maxWidth=_?m.precision:-1,m.arg=String(m.arg);break;case"c":if(!y(m.arg)){if(L=parseInt(m.arg,10),L<0||L>127)throw new Error("invalid character code. Value: "+m.arg);m.arg=y(L)?String(m.arg):h(L)}break;case"e":case"E":case"f":case"F":case"g":case"G":_||(m.precision=6),m.arg=i(m);break;default:throw new Error("invalid specifier: "+m.specifier)}m.maxWidth>=0&&m.arg.length>m.maxWidth&&(m.arg=m.arg.substring(0,m.maxWidth)),m.padZeros?m.arg=p(m.arg,m.width||m.precision,m.padRight):m.width&&(m.arg=a(m.arg,m.width,m.padRight)),A+=m.arg||"",R+=1}return A}return sr=M,sr}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var ur,Hr;function an(){if(Hr)return ur;Hr=1;var u=on();return ur=u,ur}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var fr,Jr;function sn(){if(Jr)return fr;Jr=1;var u=/%(?:([1-9]\d*)\$)?([0 +\-#]*)(\*|\d+)?(?:(\.)(\*|\d+)?)?[hlL]?([%A-Za-z])/g;function n(a){var p={mapping:a[1]?parseInt(a[1],10):void 0,flags:a[2],width:a[3],precision:a[5],specifier:a[6]};return a[4]==="."&&a[5]===void 0&&(p.precision="1"),p}function i(a){var p,h,l,y;for(h=[],y=0,l=u.exec(a);l;)p=a.slice(y,u.lastIndex-l[0].length),p.length&&h.push(p),h.push(n(l)),y=u.lastIndex,l=u.exec(a);return p=a.slice(y),p.length&&h.push(p),h}return fr=i,fr}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var cr,Yr;function un(){if(Yr)return cr;Yr=1;var u=sn();return cr=u,cr}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var pr,Qr;function fn(){if(Qr)return pr;Qr=1;function u(n){return typeof n=="string"}return pr=u,pr}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var hr,Kr;function cn(){if(Kr)return hr;Kr=1;var u=an(),n=un(),i=fn();function a(p){var h,l;if(!i(p))throw new TypeError(a("invalid argument. First argument must be a string. Value: `%s`.",p));for(h=[n(p)],l=1;l<arguments.length;l++)h.push(arguments[l]);return u.apply(null,h)}return hr=a,hr}/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var lr,Vr;function pn(){if(Vr)return lr;Vr=1;var u=cn();return lr=u,lr}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var dr,et;function hn(){if(et)return dr;et=1;var u=pn(),n=Object.prototype,i=n.toString,a=n.__defineGetter__,p=n.__defineSetter__,h=n.__lookupGetter__,l=n.__lookupSetter__;function y(w,M,c){var _,x,m,$;if(typeof w!="object"||w===null||i.call(w)==="[object Array]")throw new TypeError(u("invalid argument. First argument must be an object. Value: `%s`.",w));if(typeof c!="object"||c===null||i.call(c)==="[object Array]")throw new TypeError(u("invalid argument. Property descriptor must be an object. Value: `%s`.",c));if(x="value"in c,x&&(h.call(w,M)||l.call(w,M)?(_=w.__proto__,w.__proto__=n,delete w[M],w[M]=c.value,w.__proto__=_):w[M]=c.value),m="get"in c,$="set"in c,x&&(m||$))throw new Error("invalid argument. Cannot specify one or more accessors and a value or writable attribute in the property descriptor.");return m&&a&&a.call(w,M,c.get),$&&p&&p.call(w,M,c.set),w}return dr=y,dr}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var yr,rt;function ln(){if(rt)return yr;rt=1;var u=Kt(),n=Vt(),i=hn(),a;return u()?a=n:a=i,yr=a,yr}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var mr,tt;function dn(){if(tt)return mr;tt=1;var u=ln();function n(i,a,p){u(i,a,{configurable:!1,enumerable:!1,writable:!1,value:p})}return mr=n,mr}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var wr,nt;function He(){if(nt)return wr;nt=1;var u=dn();return wr=u,wr}/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var vr,it;function St(){if(it)return vr;it=1;function u(){return/^(?:\/?|)(?:[\s\S]*?)((?:\.{1,2}|[^\/]+?|)(?:\.[^.\/]*|))(?:[\/]*)$/}return vr=u,vr}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var gr,ot;function yn(){if(ot)return gr;ot=1;var u=St(),n=u();return gr=n,gr}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var xr,at;function mn(){if(at)return xr;at=1;var u=He(),n=St(),i=yn();return u(n,"REGEXP",i),xr=n,xr}var wn=mn();const vn=ze(wn);/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var _r,st;function bt(){if(st)return _r;st=1;function u(){return/^(?:[a-zA-Z]:|[\\\/]{2}[^\\\/]+[\\\/]+[^\\\/]+|)(?:[\\\/]|)(?:[\s\S]*?)((?:\.{1,2}|[^\\\/]+?|)(?:\.[^.\/\\]*|))(?:[\\\/]*)$/}return _r=u,_r}/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Er,ut;function gn(){if(ut)return Er;ut=1;var u=bt(),n=u();return Er=n,Er}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Sr,ft;function xn(){if(ft)return Sr;ft=1;var u=He(),n=bt(),i=gn();return u(n,"REGEXP",i),Sr=n,Sr}var _n=xn();const En=ze(_n);/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var br,ct;function It(){if(ct)return br;ct=1;function u(){return/^((?:\.(?![^\/]))|(?:(?:\/?|)(?:[\s\S]*?)))(?:\/+?|)(?:(?:\.{1,2}|[^\/]+?|)(?:\.[^.\/]*|))(?:[\/]*)$/}return br=u,br}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Ir,pt;function Sn(){if(pt)return Ir;pt=1;var u=It(),n=u();return Ir=n,Ir}/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Mr,ht;function bn(){if(ht)return Mr;ht=1;var u=He(),n=It(),i=Sn();return u(n,"REGEXP",i),Mr=n,Mr}var In=bn();const Mn=ze(In);/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Ar,lt;function Mt(){if(lt)return Ar;lt=1;function u(){return/^((?:[a-zA-Z]:|[\\\/]{2}[^\\\/]+[\\\/]+[^\\\/]+|)(?:[\\\/]|)(?:[\s\S]*?))(?:[\\\/]+?|)(?:(?:\.{1,2}|[^\\\/]+?|)(?:\.[^.\/\\]*|))(?:[\\\/]*)$/}return Ar=u,Ar}/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Br,dt;function An(){if(dt)return Br;dt=1;var u=Mt(),n=u();return Br=n,Br}/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var Or,yt;function Bn(){if(yt)return Or;yt=1;var u=He(),n=Mt(),i=An();return u(n,"REGEXP",i),Or=n,Or}var On=Bn();const Ln=ze(On);function At(u){return/^[a-zA-Z]:\\/.test(u)}function Xn(u){const n=At(u)?En().exec(u):vn().exec(u);return n===null||n.length!==2?u:n[1]}function zn(u){const n=At(u)?Ln().exec(u):Mn().exec(u);return n===null||n.length!==2?u:n[1]}var Cn;function se(){}se.prototype=Object.create(null);function N(){N.init.call(this)}N.EventEmitter=N;N.usingDomains=!1;N.prototype.domain=void 0;N.prototype._events=void 0;N.prototype._maxListeners=void 0;N.defaultMaxListeners=10;N.init=function(){this.domain=null,N.usingDomains&&Cn.active,(!this._events||this._events===Object.getPrototypeOf(this)._events)&&(this._events=new se,this._eventsCount=0),this._maxListeners=this._maxListeners||void 0};N.prototype.setMaxListeners=function(n){if(typeof n!="number"||n<0||isNaN(n))throw new TypeError('"n" argument must be a positive number');return this._maxListeners=n,this};function Bt(u){return u._maxListeners===void 0?N.defaultMaxListeners:u._maxListeners}N.prototype.getMaxListeners=function(){return Bt(this)};function Tn(u,n,i){if(n)u.call(i);else for(var a=u.length,p=Le(u,a),h=0;h<a;++h)p[h].call(i)}function Rn(u,n,i,a){if(n)u.call(i,a);else for(var p=u.length,h=Le(u,p),l=0;l<p;++l)h[l].call(i,a)}function Fn(u,n,i,a,p){if(n)u.call(i,a,p);else for(var h=u.length,l=Le(u,h),y=0;y<h;++y)l[y].call(i,a,p)}function Pn(u,n,i,a,p,h){if(n)u.call(i,a,p,h);else for(var l=u.length,y=Le(u,l),w=0;w<l;++w)y[w].call(i,a,p,h)}function Nn(u,n,i,a){if(n)u.apply(i,a);else for(var p=u.length,h=Le(u,p),l=0;l<p;++l)h[l].apply(i,a)}N.prototype.emit=function(n){var i,a,p,h,l,y,w,M=n==="error";if(y=this._events,y)M=M&&y.error==null;else if(!M)return!1;if(w=this.domain,M){if(i=arguments[1],w)i||(i=new Error('Uncaught, unspecified "error" event')),i.domainEmitter=this,i.domain=w,i.domainThrown=!1,w.emit("error",i);else{if(i instanceof Error)throw i;var c=new Error('Uncaught, unspecified "error" event. ('+i+")");throw c.context=i,c}return!1}if(a=y[n],!a)return!1;var _=typeof a=="function";switch(p=arguments.length,p){case 1:Tn(a,_,this);break;case 2:Rn(a,_,this,arguments[1]);break;case 3:Fn(a,_,this,arguments[1],arguments[2]);break;case 4:Pn(a,_,this,arguments[1],arguments[2],arguments[3]);break;default:for(h=new Array(p-1),l=1;l<p;l++)h[l-1]=arguments[l];Nn(a,_,this,h)}return!0};function Ot(u,n,i,a){var p,h,l;if(typeof i!="function")throw new TypeError('"listener" argument must be a function');if(h=u._events,h?(h.newListener&&(u.emit("newListener",n,i.listener?i.listener:i),h=u._events),l=h[n]):(h=u._events=new se,u._eventsCount=0),!l)l=h[n]=i,++u._eventsCount;else if(typeof l=="function"?l=h[n]=a?[i,l]:[l,i]:a?l.unshift(i):l.push(i),!l.warned&&(p=Bt(u),p&&p>0&&l.length>p)){l.warned=!0;var y=new Error("Possible EventEmitter memory leak detected. "+l.length+" "+n+" listeners added. Use emitter.setMaxListeners() to increase limit");y.name="MaxListenersExceededWarning",y.emitter=u,y.type=n,y.count=l.length,$n(y)}return u}function $n(u){typeof console.warn=="function"?console.warn(u):console.log(u)}N.prototype.addListener=function(n,i){return Ot(this,n,i,!1)};N.prototype.on=N.prototype.addListener;N.prototype.prependListener=function(n,i){return Ot(this,n,i,!0)};function Lt(u,n,i){var a=!1;function p(){u.removeListener(n,p),a||(a=!0,i.apply(u,arguments))}return p.listener=i,p}N.prototype.once=function(n,i){if(typeof i!="function")throw new TypeError('"listener" argument must be a function');return this.on(n,Lt(this,n,i)),this};N.prototype.prependOnceListener=function(n,i){if(typeof i!="function")throw new TypeError('"listener" argument must be a function');return this.prependListener(n,Lt(this,n,i)),this};N.prototype.removeListener=function(n,i){var a,p,h,l,y;if(typeof i!="function")throw new TypeError('"listener" argument must be a function');if(p=this._events,!p)return this;if(a=p[n],!a)return this;if(a===i||a.listener&&a.listener===i)--this._eventsCount===0?this._events=new se:(delete p[n],p.removeListener&&this.emit("removeListener",n,a.listener||i));else if(typeof a!="function"){for(h=-1,l=a.length;l-- >0;)if(a[l]===i||a[l].listener&&a[l].listener===i){y=a[l].listener,h=l;break}if(h<0)return this;if(a.length===1){if(a[0]=void 0,--this._eventsCount===0)return this._events=new se,this;delete p[n]}else kn(a,h);p.removeListener&&this.emit("removeListener",n,y||i)}return this};N.prototype.off=function(u,n){return this.removeListener(u,n)};N.prototype.removeAllListeners=function(n){var i,a;if(a=this._events,!a)return this;if(!a.removeListener)return arguments.length===0?(this._events=new se,this._eventsCount=0):a[n]&&(--this._eventsCount===0?this._events=new se:delete a[n]),this;if(arguments.length===0){for(var p=Object.keys(a),h=0,l;h<p.length;++h)l=p[h],l!=="removeListener"&&this.removeAllListeners(l);return this.removeAllListeners("removeListener"),this._events=new se,this._eventsCount=0,this}if(i=a[n],typeof i=="function")this.removeListener(n,i);else if(i)do this.removeListener(n,i[i.length-1]);while(i[0]);return this};N.prototype.listeners=function(n){var i,a,p=this._events;return p?(i=p[n],i?typeof i=="function"?a=[i.listener||i]:a=Un(i):a=[]):a=[],a};N.listenerCount=function(u,n){return typeof u.listenerCount=="function"?u.listenerCount(n):Ct.call(u,n)};N.prototype.listenerCount=Ct;function Ct(u){var n=this._events;if(n){var i=n[u];if(typeof i=="function")return 1;if(i)return i.length}return 0}N.prototype.eventNames=function(){return this._eventsCount>0?Reflect.ownKeys(this._events):[]};function kn(u,n){for(var i=n,a=i+1,p=u.length;a<p;i+=1,a+=1)u[i]=u[a];u.pop()}function Le(u,n){for(var i=new Array(n);n--;)i[n]=u[n];return i}function Un(u){for(var n=new Array(u.length),i=0;i<n.length;++i)n[i]=u[i].listener||u[i];return n}function mt(){this.promise=new Promise((u,n)=>{this.resolve=u,this.reject=n})}class Dn extends Error{constructor({message:n,code:i,data:a}){super(n),this.code=i,a&&(this.data=a),this.name=this.constructor.name}}function wt(u,n){return new Promise((i,a)=>{function p(){u.removeListener(n,h),u.removeListener("error",l)}function h(y){i(y),p()}function l(y){a(y),p()}u.addListener(n,h),u.addListener("error",l)})}class Cr extends N{constructor(n){super(),this.deferreds=Object.create(null),this.lastId=0,Object.assign(this,this.constructor.defaultOptions,n)}id(){return this.lastId++}url(n){return`${n+(this.secure?"s":"")}://${this.host}:${this.port}${this.path}`}websocket(n){return new Promise((i,a)=>{const p=h=>{h?a(h):i()};this.socket.send(JSON.stringify(n),p),globalThis.WebSocket&&this.socket instanceof globalThis.WebSocket&&p()})}async http(n){const i=await this.fetch(this.url("http"),{method:"POST",body:JSON.stringify(n),headers:{Accept:"application/json","Content-Type":"application/json"}});return i.json().then(a=>this._onmessage(a)).catch(a=>{this.emit("error",a)}),i}_buildMessage(n,i){if(typeof n!="string")throw new TypeError(`${n} is not a string`);const a={method:n,"json-rpc":"2.0",id:this.id()};return i&&Object.assign(a,{params:i}),a}async batch(n){const i=n.map(([a,p])=>this._buildMessage(a,p));return await this._send(i),i.map(({id:a})=>{this.deferreds[a]=new mt;const{promise:p}=this.deferreds[a];return p})}async call(n,i){const a=this._buildMessage(n,i);await this._send(a),this.deferreds[a.id]=new mt;const{promise:p}=this.deferreds[a.id];return p}async _send(n){this.emit("output",n);const{socket:i}=this;return i&&i.readyState===1?this.websocket(n):this.http(n)}_onresponse({id:n,error:i,result:a}){const p=this.deferreds[n];p&&(i?p.reject(new Dn(i)):p.resolve(a),delete this.deferreds[n])}_onrequest({method:n,params:i}){return this.onrequest(n,i)}_onnotification({method:n,params:i}){this.emit(n,i)}_onmessage(n){if(this.emit("input",n),Array.isArray(n))for(const i of n)this._onobject(i);else this._onobject(n)}_onobject(n){n.method===void 0?this._onresponse(n):n.id===void 0?this._onnotification(n):this._onrequest(n)}async open(){this.socket=new this.WebSocket(this.url("ws"));const n=this.socket;return n.onclose=(...i)=>{this.emit("close",...i)},n.onmessage=i=>{let a;try{a=JSON.parse(i.data)}catch(p){this.emit("error",p);return}this._onmessage(a)},n.onopen=(...i)=>{this.emit("open",...i)},n.onerror=(...i)=>{this.emit("error",...i)},wt(this,"open")}async close(){const{socket:n}=this;return n.close(),wt(this,"close")}}Cr.defaultOptions={secure:!1,host:"localhost",port:80,secret:"",path:"/jsonrpc",WebSocket:globalThis.WebSocket,fetch:globalThis.fetch.bind(globalThis)};function We(u){let n=u;return!u.startsWith("system.")&&!u.startsWith("aria2.")&&(n=`aria2.${u}`),n}function Xe(u){return u.split("aria2.")[1]||u}class Tt extends Cr{addSecret(n){let i=this.secret?[`token:${this.secret}`]:[];return Array.isArray(n)&&(i=i.concat(n)),i}_onnotification(n){const{method:i,params:a}=n,p=Xe(i);return p!==i&&this.emit(p,a),super._onnotification(n)}async call(n,...i){return super.call(We(n),this.addSecret(i))}async multicall(n){const i=[n.map(([a,...p])=>({methodName:We(a),params:this.addSecret(p)}))];return super.call("system.multicall",i)}async batch(n){return super.batch(n.map(([i,...a])=>[We(i),this.addSecret(a)]))}async listNotifications(){return(await this.call("system.listNotifications")).map(i=>Xe(i))}async listMethods(){return(await this.call("system.listMethods")).map(i=>Xe(i))}}Object.assign(Tt,{prefix:We,unprefix:Xe});Tt.defaultOptions=Object.assign({},Cr.defaultOptions,{secure:!1,host:"localhost",port:6800,secret:"",path:"/jsonrpc"});export{Tt as A,Wn as G,be as T,Se as a,Xn as b,zn as d,Gn as p};
